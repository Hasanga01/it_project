-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 21, 2021 at 12:51 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `xxx`
--

-- --------------------------------------------------------

--
-- Table structure for table `group`
--

CREATE TABLE `group` (
  `ID` int(11) NOT NULL,
  `RoomName` varchar(50) NOT NULL,
  `Group` varchar(50) NOT NULL,
  `SubGroup` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE `groups` (
  `ID` int(11) NOT NULL,
  `RoomName` varchar(50) NOT NULL,
  `GrpName` varchar(50) NOT NULL,
  `SubGroup` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`ID`, `RoomName`, `GrpName`, `SubGroup`) VALUES
(1, 'E10', '5', '5.1'),
(4, 'D45', '12', '12.2'),
(7, 'Q10', '8', '8.1'),
(9, 'R78', '7', '7.1');

-- --------------------------------------------------------

--
-- Table structure for table `lecturers`
--

CREATE TABLE `lecturers` (
  `ID` int(11) NOT NULL,
  `RoomName` varchar(50) NOT NULL,
  `LecturerName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lecturers`
--

INSERT INTO `lecturers` (`ID`, `RoomName`, `LecturerName`) VALUES
(1, '403', 'Mrs.Amali Silva'),
(4, 'H45', 'Mr.Supun De Alwis'),
(5, 'M201', 'Ms.Aruni Fernando'),
(6, 'Q800', 'Ms.Tharushi Perera');

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE `location` (
  `location_id` int(10) NOT NULL,
  `bname` varchar(50) NOT NULL,
  `rname` varchar(50) NOT NULL,
  `rtype` varchar(50) NOT NULL,
  `capacity` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `location`
--

INSERT INTO `location` (`location_id`, `bname`, `rname`, `rtype`, `capacity`) VALUES
(4, 'BM Building', 'B202', 'Laboratory', '20'),
(5, 'New Building', 'N202', 'Laboratory', '10'),
(8, 'Main Building', 'M512', 'Laboratory', '75'),
(9, 'New Building', 'N303', 'Lecture Hall', '15'),
(12, 'Hospitality Building', 'H10', 'Laboratory', '80'),
(13, 'New Building', 'N202', 'Lecture Hall', '120'),
(15, 'Main Building', 'M100', 'Laboratory', '50'),
(16, 'New Building', 'N202', 'Laboratory', '60'),
(19, 'Main Building', 'M45', 'Laboratory', '60'),
(23, 'New Building', 'N302', 'Laboratory', '60'),
(24, 'Main Building', 'M200', 'Lecture Hall', '120'),
(26, 'Main Building', 'M50', 'Laboratory', '60'),
(29, 'Hospitality Building', 'H851', 'Lecture Hall', '40'),
(32, 'New Building', 'R45', 'Laboratory', '120'),
(33, 'BM Building', 'B505', 'Laboratory', '10'),
(34, 'Main Building', 'Y25', 'Laboratory', '25'),
(35, 'Main Building', 'N78', 'Laboratory', '45'),
(36, 'New Building', 'N3N', 'Laboratory', '100');

-- --------------------------------------------------------

--
-- Table structure for table `modules`
--

CREATE TABLE `modules` (
  `ID` int(11) NOT NULL,
  `RoomName` varchar(50) NOT NULL,
  `SubjectName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `modules`
--

INSERT INTO `modules` (`ID`, `RoomName`, `SubjectName`) VALUES
(2, '800', 'OSSA'),
(3, '420', 'CN'),
(4, 'N3N', 'OPP'),
(5, 'M200', 'SE'),
(6, 'D21', 'DMS');

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `ID` int(11) NOT NULL,
  `RoomName` varchar(50) NOT NULL,
  `Session` varchar(20) NOT NULL,
  `Session1` varchar(20) NOT NULL,
  `Session2` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`ID`, `RoomName`, `Session`, `Session1`, `Session2`) VALUES
(1, 'N30', 'SE', 'Lecture', 'Tute'),
(3, '502', 'OSSA', 'Tute', 'Lecture'),
(4, 'D01', 'DMS', 'Lab Sheet', 'Tute');

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `ID` int(11) NOT NULL,
  `RoomName` varchar(50) NOT NULL,
  `Subject` varchar(50) NOT NULL,
  `Tag` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`ID`, `RoomName`, `Subject`, `Tag`) VALUES
(2, 'N100', 'Data Science', 'Lecture'),
(3, 'D403', 'OOP', 'Lab'),
(5, 'N122', 'CN', 'Tutorial'),
(6, 'E30', 'Civil', 'Lecture'),
(8, 'R10', 'SE', 'Lab');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `group`
--
ALTER TABLE `group`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `lecturers`
--
ALTER TABLE `lecturers`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `location`
--
ALTER TABLE `location`
  ADD PRIMARY KEY (`location_id`);

--
-- Indexes for table `modules`
--
ALTER TABLE `modules`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `group`
--
ALTER TABLE `group`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `lecturers`
--
ALTER TABLE `lecturers`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `location`
--
ALTER TABLE `location`
  MODIFY `location_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `modules`
--
ALTER TABLE `modules`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `sessions`
--
ALTER TABLE `sessions`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `subject`
--
ALTER TABLE `subject`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
